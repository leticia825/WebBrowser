﻿namespace WebBrowser.Data
{


    partial class BookmarksDataSet
    {
    }
}

namespace WebBrowser.Data.BookmarksDataSetTableAdapters {
    
    
    public partial class BookmarksTableAdapter {
    }
}
